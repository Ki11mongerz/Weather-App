package com.example.weathersnow

data class Clouds(
    val all: Int
)