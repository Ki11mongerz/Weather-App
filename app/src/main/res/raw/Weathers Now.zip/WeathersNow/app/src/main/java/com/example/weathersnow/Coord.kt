package com.example.weathersnow

data class Coord(
    val lat: Double,
    val lon: Double
)