package com.example.weathersnow

data class Wind(
    val deg: Int,
    val speed: Double
)